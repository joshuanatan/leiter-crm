<body class="animsition page-login-v2 layout-full" style = "background-color:white">
    <div class="page" data-animsition-in="fade-in" data-animsition-out="fade-out">
            <div class="page-content">