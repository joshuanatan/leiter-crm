<div class="page-header">
    <h1 class="page-title">CRM - ORDER CONFIRMATION</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item"><a href="javascript:void(0)">CRM</a></li>
        <li class="breadcrumb-item active">Order Confirmation</li>
    </ol>
</div>