<div class="col-lg-3">
    <!-- Page Widget -->
    <div class="card card-shadow text-center">
        <div class="card-block">
            <a class="avatar avatar-lg" href="javascript:void(0)">
                <img src="<?php echo base_url();?>global/portraits/5.jpg" alt="...">
            </a>
            <h4 class="profile-user">Terrance arnold</h4>
            <p class="profile-job">Sales Manager</p>
            <h6 class="profile-user">0896-1696-1915</h4>
            <h6 class="profile-user">joshuanatan.jn@gmail.com</h4>
            
        </div>
        <div class="card-footer">
            <div class="row no-space">
                <div class="col-12">
                    <strong class="profile-stat-count">13/03/2016</strong>
                    <span>Registered Date</span>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Widget -->
</div>