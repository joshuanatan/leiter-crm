<div class="col-lg-9">
    <div class="panel">
        <div class="panel-body nav-tabs-animate nav-tabs-horizontal" data-plugin="tabs">