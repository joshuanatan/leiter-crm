<div class="page-header">
    <h1 class="page-title">CRM - KPI</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item"><a href="javascript:void(0)">Report</a></li>
        <li class="breadcrumb-item active">KPI</li>
    </ol>
</div>