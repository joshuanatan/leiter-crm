<link rel="stylesheet" href="<?php echo base_url();?>global/vendor/chartist/chartist.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/examples/css/widgets/chart.css">