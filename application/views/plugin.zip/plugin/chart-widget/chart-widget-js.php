
<script src="<?php echo base_url();?>global/vendor/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url();?>global/vendor/chartist/chartist.min.js"></script>
<script src="<?php echo base_url();?>global/vendor/matchheight/jquery.matchHeight-min.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/matchheight.js"></script>
<script src="<?php echo base_url();?>assets/examples/js/widgets/chart.js"></script>