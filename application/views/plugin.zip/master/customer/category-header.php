<div class="page-header">
    <h1 class="page-title">MASTER CUSTOMER DATA</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item"><a href="javascript:void(0)">Master</a></li>
        <li class="breadcrumb-item active">Customer Data</li>
    </ol>
</div>