<script src="<?php echo base_url();?>global/js/Plugin/responsive-tabs.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/tabs.js"></script>
<script>
      (function(document, window, $){
        'use strict';
    
        var Site = window.Site;
        $(document).ready(function(){
          Site.run();
        });
      })(document, window, jQuery);
    </script>