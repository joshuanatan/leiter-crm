<div class="page">
	<div class="page-content">
		<h2><small>Welcome</small> <?php echo $this->session->nama_user;?></h2>
		<p>PT LEITER INDONESIA - CRM</p>
	</div>
</div>