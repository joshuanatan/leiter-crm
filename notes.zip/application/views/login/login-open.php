<body class="animsition page-login-v2 layout-full page-dark">
    <div class="page" data-animsition-in="fade-in" data-animsition-out="fade-out">
            <div class="page-content">