<div class="page-brand-info">
    <div class="brand">
        <img class="brand-img" src="<?php echo base_url();?>assets/images/logo@2x.png" alt="...">
        <h2 class="brand-text font-size-40">PT. LEITER INDONESIA</h2>
    </div>
    <p class="font-size-20">deliver quality, gain efficiency</p>
</div>

                
