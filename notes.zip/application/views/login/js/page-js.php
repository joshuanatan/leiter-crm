
<script src="<?php echo base_url();?>global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/jquery-placeholder.js"></script>

<script>
(function(document, window, $){
    'use strict';

    var Site = window.Site;
    $(document).ready(function(){
    Site.run();
    });
})(document, window, jQuery);
</script>