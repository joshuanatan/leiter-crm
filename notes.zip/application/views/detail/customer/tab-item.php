<ul class="nav nav-tabs nav-tabs-line" role="tablist">
    <li class="nav-item" role="presentation"><a class="active nav-link" data-toggle="tab" href="#activities"
        aria-controls="activities" role="tab">Activities <span class="badge badge-pill badge-danger">5</span></a></li>
    <!--<li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#profile" aria-controls="profile" role="tab">Profile</a>
    </li>
    <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#messages" aria-controls="messages"
        role="tab">Messages</a></li>
    <li class="nav-item dropdown">
        <a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#" aria-expanded="false">Menu </a>
        <div class="dropdown-menu" role="menu">
        <a class="active dropdown-item" data-toggle="tab" href="#activities" aria-controls="activities"
            role="tab">Activities <span class="badge badge-pill badge-danger">5</span></a>
        <a class="dropdown-item" data-toggle="tab" href="#profile" aria-controls="profile"
            role="tab">Profile</a>
        <a class="dropdown-item" data-toggle="tab" href="#messages" aria-controls="messages"
            role="tab">Messages</a>
        </div>
    </li>-->
</ul>